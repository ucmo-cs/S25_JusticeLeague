import React, { useState, useEffect } from "react";
import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";
import Dashboard from "./Dashboard";
import LoginPage from "./LoginPage";
import "./styles.css"; // Import CSS

const App = () => {
  const [isLoggedIn, setIsLoggedIn] = useState(false);

  useEffect(() => {
    const userStatus = localStorage.getItem("isLoggedIn");
    setIsLoggedIn(userStatus === "true");
  }, []);

  const handleLogout = () => {
    localStorage.setItem("isLoggedIn", "false");
    setIsLoggedIn(false);
  };

  return (
    <Router>
      <div className="container">
        {/* Combined Header and Navigation Bar */}
        <header className="header">
          <div className="header-content">
            <img src="/images/Headerlogo.png" alt="Commerce Bank Logo" className="logo" />
            {/* Optionally uncomment the header title */}
            {/* <h1 className="header-title">Commerce Bank: URL Checking System</h1> */}
          </div>
        </header>

        {/* Sub-header for FDIC Insured Info */}
        <div className="sub-header">
          <span className="fdic-logo">FDIC</span>
          <span className="fdic-text">FDIC-Insured � Backed by the full faith and credit of the U.S. Government</span>
        </div>

        {/* Routes */}
        <Routes>
          <Route path="/" element={<LoginPage setIsLoggedIn={setIsLoggedIn} />} />
          <Route path="/dashboard" element={<Dashboard setIsLoggedIn={setIsLoggedIn} />} />
          <Route path="/login" element={<LoginPage setIsLoggedIn={setIsLoggedIn} />} />
        </Routes>
      </div>
    </Router>
  );
};

// useEffect(()=>{


// fetch("http://localhost:8081/urls", {method:"GET"})
// .then(res =>res.json())
// .then(res=>){
//   setURL(res)});

// },[])

// {urls.map(url =>
//  <tr key = {url.url_id}>
//   <td>{url.url_id}</td>
//   <td>{url.name}</td>
//   <td>{url.url}</td>
//  </tr>

// )}



export default App;