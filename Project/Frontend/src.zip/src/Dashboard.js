import React, { useState, useEffect } from "react";
import { useNavigate } from "react-router-dom";
import "./styles.css";

const Dashboard = ({ setIsLoggedIn }) => {
    const navigate = useNavigate();
    const [savedUrls, setSavedUrls] = useState([]);
    const [newUrl, setNewUrl] = useState("");

    useEffect(() => {
        const userId = localStorage.getItem("userId");
        fetch(`http://localhost:8081/url/${userId}`)
            .then((response) => response.json())
            .then((data) => {
                console.log("Fetched URLs:", data);
                setSavedUrls(data);
            })
            .catch((error) => console.error("Error fetching URLs:", error));
    }, []);

    const handleLogout = () => {
        localStorage.setItem("isLoggedIn", "false");
        setIsLoggedIn(false);
        navigate("/login");
    };

    const handleCheckboxChange = (id) => {
        setSavedUrls((prevUrls) =>
            prevUrls.map((url) =>
                url.url_id === id ? { ...url, selected: !url.selected } : url
            )
        );
    };

    const handleDelete = () => {
        const selectedIds = savedUrls.filter(url => url.selected).map(url => url.url_id);

        if (selectedIds.length === 0) {
            alert("Please select at least one URL to delete.");
            return;
        }

        // Send DELETE request to the backend
        fetch("http://localhost:8081/url", {
            method: "DELETE",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify(selectedIds), // Send array of selected IDs
        })
            .then((response) => response.json())  // Assuming backend sends the updated URLs list
            .then((updatedUrls) => {
                // Update the savedUrls state by removing the URLs that were deleted
                setSavedUrls(updatedUrls);  // Replace the state with the updated URLs
                alert("Selected URLs deleted.");
            })
            .catch((error) => {
                console.error("Error deleting URLs:", error);
            });
    };

    const handleAddUrl = () => {
        if (newUrl.trim() === "") return;

        const userId = localStorage.getItem("userId");

        const urlRequest = {
            url: newUrl,
            userId: userId,
        };

        fetch("http://localhost:8081/url", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(urlRequest),
        })
            .then((res) => res.json())
            .then((newSavedUrl) => {
                setSavedUrls((prevUrls) => [...prevUrls, newSavedUrl]); // Add to state
                setNewUrl(""); // Clear input
            })
            .catch((error) => {
                console.error("Failed to add URL:", error);
            });
    };
    const handleEditSelected = () => {
        const updatedUrls = savedUrls.filter(url => url.selected).map(url => {
            const updatedUrl = document.getElementById(`url-${url.url_id}`).innerText;  // Get updated text from the contenteditable element
            return {
                ...url,
                url: updatedUrl,  // Set the updated URL
            };
        });

        if (updatedUrls.length === 0) {
            alert("Please select at least one URL to edit.");
            return;
        }

        // Send the updated URLs to the backend for saving
        fetch("http://localhost:8081/urls", {  // Ensure this endpoint is correct for updating URLs
            method: "PUT",  // PUT for updating
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify(updatedUrls),  // Send the updated URLs
        })
            .then((response) => response.json())
            .then((responseData) => {
                console.log("Updated URLs:", responseData);  // Log to check the response

                // Update the local state with the new data from the backend
                setSavedUrls((prevUrls) =>
                    prevUrls.map((url) => {
                        const updatedUrl = responseData.find((u) => u.url_id === url.url_id);
                        return updatedUrl ? updatedUrl : url;
                    })
                );
            })
            .catch((error) => {
                console.error("Error updating URLs:", error);
            });
    };
    const handleRescan = () => {
        const selectedUrls = savedUrls.filter(url => url.selected);

        if (selectedUrls.length === 0) {
            alert("Please select at least one URL to rescan.");
            return;
        }

        // Collect selected URL IDs (ensure they are Long/Number)
        const selectedUrlIds = selectedUrls.map(url => url.url_id);

        // Send the selected URLs to the backend for rescanning
        fetch("http://localhost:8081/rescan", {  // Correct endpoint
            method: "PUT",  // PUT for rescanning
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify(selectedUrlIds),  // Send the array directly
        })
            .then((response) => response.json())
            .then((updatedUrls) => {
                console.log("Updated URLs:", updatedUrls);  // Log to inspect the response structure

                // Ensure updatedUrls is an array before trying to use .find()
                if (Array.isArray(updatedUrls)) {
                    setSavedUrls((prevUrls) =>
                        prevUrls.map((url) => {
                            const updatedUrl = updatedUrls.find((u) => u.url_id === url.url_id);
                            return updatedUrl ? updatedUrl : url;
                        })
                    );
                } else {
                    console.error("Unexpected response format:", updatedUrls);
                }
            })
            .catch((error) => console.error("Error rescanning URL:", error));
    };



    return (
        <div className="dashboard">
            <header className="header">
                <img src="/images/Headerlogo.png" alt="Commerce Bank Logo" className="logo" />
                <h1>Commerce Bank: URL Checking System</h1>
            </header>

            <div className="logout-container">
                <button className="logout-btn" onClick={handleLogout}>Logout</button>
            </div>

            <h2>Your Saved URLs</h2>
            <input
                type="text"
                placeholder="Enter a new URL"
                value={newUrl}
                onChange={(e) => setNewUrl(e.target.value)}
            />
            <button className="rescan-btn" onClick={handleAddUrl}>Add URL</button>
            <button className="edit-btn" onClick={handleEditSelected}>Edit Selected</button>
            <button className="rescan-btn" onClick={handleRescan}>Rescan Selected</button>
            <button className="delete-btn" onClick={handleDelete} style={{ backgroundColor: "red", color: "white", marginLeft: "10px" }}>
                Delete Selected
            </button>

            <table>
                <thead>
                    <tr>
                        <th>Select</th>
                        <th>URL</th>
                        <th>SSL Certificates</th>
                        <th>Response Code</th>
                        <th>SSL Protocol/Cipher Used</th>
                        <th>Response Headers</th>
                    </tr>
                </thead>
                <tbody>
                    {savedUrls.map((savedUrl) => (
                        <tr key={savedUrl.url_id}>
                            <td>
                                <input
                                    type="checkbox"
                                    checked={savedUrl.selected || false} // Ensure `selected` property is used to check if it's selected
                                    onChange={() => handleCheckboxChange(savedUrl.url_id)} // Use `url_id` to uniquely identify the URL
                                />
                            </td>
                            <td className="table-cell"
                                id={`url-${savedUrl.url_id}`}  // Unique id for each URL cell
                                data-full-text={savedUrl.url}
                                contentEditable>
                                {savedUrl.url}
                            </td>
                            <td className="table-cell" data-full-text={savedUrl.ssl || "N/A"}>
                                {savedUrl.ssl || "N/A"}
                            </td>
                            <td className="table-cell" data-full-text={savedUrl.resCode || "N/A"}>
                                {savedUrl.resCode || "N/A"}
                            </td>
                            <td className="table-cell" data-full-text={savedUrl.sslPro || "N/A"}>
                                {savedUrl.sslPro || "N/A"}
                            </td>
                            <td className="table-cell" data-full-text={savedUrl.resHead || "N/A"}>
                                {savedUrl.resHead || "N/A"}
                            </td>
                        </tr>
                    ))}
                </tbody>
            </table>
        </div>
    );
};

export default Dashboard;
