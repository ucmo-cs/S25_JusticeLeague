import React, { useState } from "react";
import { useNavigate } from "react-router-dom";
import "./styles.css";

const LoginPage = ({ setIsLoggedIn }) => {
    const [username, setUsername] = useState("");
    const [password, setPassword] = useState("");
    const navigate = useNavigate();

    const handleLogin = () => {
        console.log("Logging in:", username);
        const loginRequest = {
            userId: username,
            password: password
        };

        fetch("http://localhost:8081/login", {
            method: "POST",
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(loginRequest),
        })
            .then((response) => {
                if (response.ok) {
                    localStorage.setItem("isLoggedIn", "true");
                    localStorage.setItem("userId", username); // Set username or a unique user identifier
                    setIsLoggedIn(true);
                    navigate("/dashboard");
                } else {
                    alert("Invalid login credentials.");
                }
            })
            .catch((error) => console.error("Login error:", error));
    };

    return (
        <div className="login-container">
            <div className="login-box">
                <h2>Login</h2>
                <input
                    type="text"
                    placeholder="Username"
                    value={username}
                    onChange={(e) => setUsername(e.target.value)}
                />
                <input
                    type="password"
                    placeholder="Password"
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                />
                <button className="login-btn" onClick={handleLogin}>Login</button>
            </div>
        </div>
    );
};

export default LoginPage;
